const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./batches.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS batches (
    batch_id TEXT PRIMARY KEY,
    product_name TEXT,
    manufacturer TEXT,
    registration_no TEXT,
    lot_no TEXT,
    mfg_date TEXT,
    exp_date TEXT,
    net_content TEXT,
    mrp TEXT,
    license_no TEXT
  )`);
});

module.exports = db;
