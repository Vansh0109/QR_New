const xlsx = require('xlsx');
const QRCode = require('qrcode');
const db = require('./db');
const fs = require('fs');

const workbook = xlsx.readFile('./fake_data.xlsx');
const sheet = workbook.Sheets[workbook.SheetNames[0]];
const data = xlsx.utils.sheet_to_json(sheet);

fs.mkdirSync('./qrcodes', { recursive: true });

async function insertAndGenerate() {
  for (let row of data) {
    const batchId = row.batch_no;
    const url = `https://yourdomain.com/batch/${batchId}`;
    await QRCode.toFile(`./qrcodes/${batchId}.png`, url);

    db.run(
      `INSERT INTO batches VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        batchId,
        row.product_name,
        row.manufacturer,
        row.registration_no,
        row.lot_no,
        row.mfg_date,
        row.exp_date,
        row.net_content,
        row.mrp,
        row.license_no
      ]
    );
  }
  console.log("QRs generated and data inserted.");
}

insertAndGenerate();
