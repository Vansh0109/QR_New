import { Card, CardContent } from "@/components/ui/card";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

export default function BatchInfoPage() {
  const { batchId } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/api/batches/${batchId}`)
      .then(res => res.json())
      .then(setData)
      .catch(() => setData(null));
  }, [batchId]);

  if (!data) {
    return <div className="p-4 text-center">Loading or Batch Not Found</div>;
  }

  return (
    <div className="max-w-xl mx-auto mt-10">
      <Card className="shadow-xl border p-4">
        <CardContent>
          <h1 className="text-2xl font-bold mb-4 text-green-700">Pesticide Batch Details</h1>
          <ul className="space-y-2 text-base">
            <li><strong>Product Name:</strong> {data.product_name}</li>
            <li><strong>Manufacturer:</strong> {data.manufacturer}</li>
            <li><strong>Registration No.:</strong> {data.registration_no}</li>
            <li><strong>Batch No.:</strong> {data.batch_id}</li>
            <li><strong>Lot No.:</strong> {data.lot_no}</li>
            <li><strong>Mfg Date:</strong> {data.mfg_date}</li>
            <li><strong>Expiry Date:</strong> {data.exp_date}</li>
            <li><strong>Net Content:</strong> {data.net_content}</li>
            <li><strong>MRP:</strong> {data.mrp}</li>
            <li><strong>License No.:</strong> {data.license_no}</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
