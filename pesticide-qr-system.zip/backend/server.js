const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());

app.get('/api/batches/:batchId', (req, res) => {
  db.get("SELECT * FROM batches WHERE batch_id = ?", [req.params.batchId], (err, row) => {
    if (err) return res.status(500).send(err);
    if (!row) return res.status(404).send({ error: "Not found" });
    res.send(row);
  });
});

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
